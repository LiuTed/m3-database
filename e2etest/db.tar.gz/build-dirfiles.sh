#!/bin/bash
#set -e
if [[ $# -ne 1 ]]; then
    echo "Usage: $0 <prefix>"
    exit -1
fi

# $1: carrier, $2: 1 or 2, $3: prefix
build_one() {
    outfile=${3}-${1}.$2
    carrier=$1
    echo "Building for carrier $carrier, trip $2, to file $outfile"
    
    echo -n "" > $outfile
#    for df in datafiles/*${carrier}*.$2; do
#        echo "`pwd`/$df" >> $outfile
#    done

    echo "F" >> $outfile 
    echo -n "" > hofiles/${carrier}-total.$2.csv
    for df in hofiles/*${carrier}*.$2; do
        cat $df >> hofiles/${carrier}-total.$2.csv
    done
    echo "`pwd`/hofiles/${carrier}-total.$2.csv" >> $outfile

    echo "F" >> $outfile 
    lng_file=bdfiles/$1.$2.long_only.csv
    lat_file=bdfiles/$1.$2.lat_only.csv
    ./build-bdfiles.py $lng_file $lat_file > bdfiles/$1.$2.bdtotal.csv
    echo "`pwd`/bdfiles/$1.$2.bdtotal.csv" >> $outfile
}

build_one Mobile 1 $1
build_one Mobile 2 $1

build_one Unicom 1 $1
build_one Unicom 2 $1

build_one Teleco 1 $1
build_one Teleco 2 $1

rm database.tar* -f
echo "packaging data"
tar cf database.tar ./build-dirfiles.sh ./build-bdfiles.py ./hofiles/*total* ./bdfiles/* ./datafiles/ $1*
echo "Compressing data..."
gzip --best database.tar
du -sh database.tar.gz
