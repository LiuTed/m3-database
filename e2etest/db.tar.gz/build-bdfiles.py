#!/usr/bin/python3
"""
build-bdfiles.py

Usage:
    python3 build-bdfiles.py <long only> <lat only>

input format:
    <cid> <location factor> <bias> <confidence> <mean_loc> <dev_loc> <status>

output format:
    <cid> <lng bound> <lng confidence> <lat factor> <lat confidence> <status(-1,0,1)>

"""

import sys

if len(sys.argv) != 3:
    print("Usage: python3 {} <long_only file> <lat_only file>".format(sys.argv[0]))
    exit(-1)

lng_dic = {}
lat_dic = {}
status_dic = {}

def judge_status(s):
    if s == 'failed"':
        return -1
    if s == 'succeeded/failed':
        return 0
    if s == 'succeeded"':
        return 1

def fill_dic(fname, dic):
    global status_dic
    with open(fname, "r") as fin:
        fin.readline()
        for line in fin:
            vec = line.rstrip('\n').split()
            cid = int(vec[0])
            status = vec[-1]
            status_int = judge_status(status)
            status_dic[cid] = status_int
#            print(vec[1:6], status, status_int, file=sys.stderr)
            loc_fac, bias, conf, mean_loc, dev_loc = map(float, vec[1:6])
            if status_int != 0 or loc_fac == 0:
                if loc_fac == 0 and status_int == 0:
                    print("[WARNING] succ/fail with loc_fac == 0: file: {}, cid: {}".format(fname, cid))
                crit, conf = 0, 0
            else:
                crit = mean_loc - bias * dev_loc / loc_fac
            dic[cid] =  crit, conf

fill_dic(sys.argv[1], lng_dic)
fill_dic(sys.argv[2], lat_dic)

for cid in lng_dic.keys():
    if not cid in lat_dic:
        continue
    a,b = lng_dic[cid]
    c,d = lat_dic[cid]
    print("{} {} {} {} {} {}"
            .format(cid, a, b, c, d, status_dic[cid]))
